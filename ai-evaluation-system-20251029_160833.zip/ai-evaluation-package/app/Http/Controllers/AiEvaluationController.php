<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Artisan;
use App\Models\VideoSubmission;
use App\Models\AiEvaluation;
use App\Jobs\BatchAiEvaluationJob;

class AiEvaluationController extends Controller
{
    /**
     * AI 일괄 평가 목록
     */
    public function batchEvaluationList(Request $request)
    {
        $admin = Auth::guard('admin')->user();
        
        if (!$admin || !in_array($admin->role, ['admin', 'super_admin'])) {
            return redirect()->route('admin.login')->with('error', '접근 권한이 없습니다.');
        }

        // 통계 계산
        $totalSubmissions = VideoSubmission::count();
        $completedEvaluations = VideoSubmission::whereHas('aiEvaluations', function($query) {
            $query->where('processing_status', AiEvaluation::STATUS_COMPLETED);
        })->count();
        $processingEvaluations = VideoSubmission::whereHas('aiEvaluations', function($query) {
            $query->where('processing_status', AiEvaluation::STATUS_PROCESSING);
        })->count();
        $failedEvaluations = VideoSubmission::whereHas('aiEvaluations', function($query) {
            $query->where('processing_status', AiEvaluation::STATUS_FAILED);
        })->count();
        $pendingSubmissions = VideoSubmission::whereDoesntHave('aiEvaluations')->count();

        // 영상 목록
        $submissions = VideoSubmission::with(['aiEvaluations', 'institution'])
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        return view('admin.batch-evaluation', compact(
            'totalSubmissions',
            'completedEvaluations',
            'processingEvaluations',
            'failedEvaluations',
            'pendingSubmissions',
            'submissions'
        ));
    }

    /**
     * AI 일괄 평가 시작
     */
    public function startBatchAiEvaluation(Request $request)
    {
        $admin = Auth::guard('admin')->user();
        
        if (!$admin || !in_array($admin->role, ['admin', 'super_admin'])) {
            return response()->json(['success' => false, 'message' => '접근 권한이 없습니다.'], 403);
        }

        try {
            // 평가할 영상들 가져오기
            $submissions = VideoSubmission::whereDoesntHave('aiEvaluations', function($query) {
                $query->where('processing_status', AiEvaluation::STATUS_COMPLETED);
            })->get();

            if ($submissions->isEmpty()) {
                return response()->json([
                    'success' => false,
                    'message' => '평가할 영상이 없습니다.'
                ]);
            }

            $queuedCount = 0;
            foreach ($submissions as $submission) {
                // 기존 처리 중인 평가가 있는지 확인
                $existingProcessing = AiEvaluation::where('video_submission_id', $submission->id)
                    ->where('processing_status', AiEvaluation::STATUS_PROCESSING)
                    ->exists();

                if (!$existingProcessing) {
                    // 파일 존재 확인
                    if ($submission->isStoredOnS3()) {
                        if (!Storage::disk('s3')->exists($submission->video_file_path)) {
                            Log::warning('S3 파일이 존재하지 않음', [
                                'submission_id' => $submission->id,
                                'video_path' => $submission->video_file_path
                            ]);
                            continue;
                        }
                    } else {
                        if (!Storage::disk('public')->exists($submission->video_file_path)) {
                            Log::warning('로컬 파일이 존재하지 않음', [
                                'submission_id' => $submission->id,
                                'video_path' => $submission->video_file_path
                            ]);
                            continue;
                        }
                    }

                    // 작업 큐에 추가
                    BatchAiEvaluationJob::dispatch($submission->id, $admin->id);
                    $queuedCount++;
                }
            }

            Log::info('AI 일괄 평가 시작', [
                'admin_id' => $admin->id,
                'total_submissions' => $submissions->count(),
                'queued_count' => $queuedCount
            ]);

            return response()->json([
                'success' => true,
                'message' => "{$queuedCount}개의 영상이 평가 큐에 추가되었습니다.",
                'data' => [
                    'queued_count' => $queuedCount,
                    'total_submissions' => $submissions->count()
                ]
            ]);

        } catch (\Exception $e) {
            Log::error('AI 일괄 평가 시작 실패: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'AI 일괄 평가 시작에 실패했습니다: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * AI 일괄 평가 취소
     */
    public function cancelBatchAiEvaluation(Request $request)
    {
        $admin = Auth::guard('admin')->user();
        
        if (!$admin || !in_array($admin->role, ['admin', 'super_admin'])) {
            return response()->json(['success' => false, 'message' => '접근 권한이 없습니다.'], 403);
        }

        try {
            // 처리 중인 평가들을 실패 상태로 변경
            $processingEvaluations = AiEvaluation::where('processing_status', AiEvaluation::STATUS_PROCESSING)->get();
            $cancelledCount = 0;

            foreach ($processingEvaluations as $evaluation) {
                $evaluation->update([
                    'processing_status' => AiEvaluation::STATUS_FAILED,
                    'error_message' => '관리자에 의해 취소되었습니다.'
                ]);
                $cancelledCount++;
            }

            // 큐 클리어
            Artisan::call('queue:clear', ['--queue' => 'default']);

            Log::info('AI 일괄 평가 취소', [
                'admin_id' => $admin->id,
                'cancelled_count' => $cancelledCount
            ]);

            return response()->json([
                'success' => true,
                'message' => "{$cancelledCount}개의 평가가 취소되었습니다.",
                'data' => [
                    'cancelled_count' => $cancelledCount
                ]
            ]);

        } catch (\Exception $e) {
            Log::error('AI 일괄 평가 취소 실패: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'AI 일괄 평가 취소에 실패했습니다: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * AI 평가 진행 상황 조회
     */
    public function getBatchAiEvaluationProgress(Request $request)
    {
        $admin = Auth::guard('admin')->user();
        
        if (!$admin || !in_array($admin->role, ['admin', 'super_admin'])) {
            return response()->json(['success' => false, 'message' => '접근 권한이 없습니다.'], 403);
        }

        try {
            $totalSubmissions = VideoSubmission::count();
            $completedEvaluations = VideoSubmission::whereHas('aiEvaluations', function($query) {
                $query->where('processing_status', AiEvaluation::STATUS_COMPLETED);
            })->count();
            $processingEvaluations = VideoSubmission::whereHas('aiEvaluations', function($query) {
                $query->where('processing_status', AiEvaluation::STATUS_PROCESSING);
            })->count();
            $noFileEvaluations = VideoSubmission::whereHas('aiEvaluations', function($query) {
                $query->where('processing_status', AiEvaluation::STATUS_FAILED)
                      ->where('error_message', '영상 파일이 존재하지 않습니다.');
            })->count();
            $failedEvaluations = VideoSubmission::whereHas('aiEvaluations', function($query) {
                $query->where('processing_status', AiEvaluation::STATUS_FAILED)
                      ->where(function($q) {
                          $q->where('error_message', '!=', '영상 파일이 존재하지 않습니다.')
                            ->orWhereNull('error_message');
                      });
            })->count();
            $pendingSubmissions = VideoSubmission::whereDoesntHave('aiEvaluations')->count();

            $progressPercentage = $totalSubmissions > 0 ? round(($completedEvaluations / $totalSubmissions) * 100, 1) : 0;

            // 최근 평가 결과
            $recentEvaluations = AiEvaluation::with('videoSubmission')
                ->where('processing_status', AiEvaluation::STATUS_COMPLETED)
                ->orderBy('updated_at', 'desc')
                ->limit(5)
                ->get();

            return response()->json([
                'success' => true,
                'data' => [
                    'total_submissions' => $totalSubmissions,
                    'completed_evaluations' => $completedEvaluations,
                    'processing_evaluations' => $processingEvaluations,
                    'failed_evaluations' => $failedEvaluations,
                    'no_file_evaluations' => $noFileEvaluations,
                    'pending_submissions' => $pendingSubmissions,
                    'progress_percentage' => $progressPercentage,
                    'recent_evaluations' => $recentEvaluations->map(function($evaluation) {
                        return [
                            'id' => $evaluation->id,
                            'student_name' => $evaluation->videoSubmission->student_name,
                            'total_score' => $evaluation->total_score,
                            'pronunciation_score' => $evaluation->pronunciation_score,
                            'fluency_score' => $evaluation->fluency_score,
                            'comprehension_score' => $evaluation->comprehension_score,
                            'completed_at' => $evaluation->updated_at->format('Y-m-d H:i:s')
                        ];
                    })
                ]
            ]);

        } catch (\Exception $e) {
            Log::error('AI 평가 진행 상황 조회 실패: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => '진행 상황 조회에 실패했습니다.'
            ], 500);
        }
    }
}
