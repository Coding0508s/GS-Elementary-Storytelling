# AI 일괄 체점 시스템

Laravel 기반 AI 일괄 체점 시스템으로, OpenAI Whisper와 GPT-4를 사용하여 영상 파일을 자동으로 평가하는 시스템입니다.

## 🎯 주요 기능

- **자동 음성 인식**: OpenAI Whisper를 사용한 정확한 음성-텍스트 변환
- **AI 평가**: GPT-4를 사용한 영어 발표 평가 (발음, 어휘, 유창성)
- **대용량 파일 처리**: 25MB 이상 파일의 분할 처리 지원
- **실시간 모니터링**: 진행 상황 실시간 확인 및 제어
- **관리자 인터페이스**: 직관적인 웹 기반 관리 도구

## 🏗️ 시스템 아키텍처

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   관리자 대시보드  │───▶│   Queue Worker   │───▶│   OpenAI API    │
│                 │    │                  │    │  (Whisper+GPT)  │
└─────────────────┘    └──────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│  Video Upload   │    │  BatchAiEvalJob  │    │  FFmpeg Audio   │
│                 │    │                  │    │   Extraction    │
└─────────────────┘    └──────────────────┘    └─────────────────┘
```

## 📁 파일 구조

```
app/
├── Http/Controllers/
│   └── AiEvaluationController.php    # AI 평가 컨트롤러
├── Jobs/
│   └── BatchAiEvaluationJob.php      # AI 평가 작업
├── Models/
│   └── AiEvaluation.php             # AI 평가 모델
└── Services/
    └── OpenAiService.php            # OpenAI 서비스

resources/views/admin/
└── batch-evaluation.blade.php       # 일괄 평가 관리 페이지

database/migrations/
└── *_create_ai_evaluations_table.php # AI 평가 테이블 마이그레이션
```

## 🚀 빠른 시작

1. **의존성 설치**
   ```bash
   composer install
   ```

2. **환경 설정**
   ```bash
   cp .env.example .env
   # OpenAI API 키 설정
   ```

3. **데이터베이스 마이그레이션**
   ```bash
   php artisan migrate
   ```

4. **Queue Worker 시작**
   ```bash
   php artisan queue:work
   ```

5. **관리자 페이지 접속**
   - `/admin/batch-evaluation` 경로로 접속

## 📊 평가 기준

- **발음 점수 (0-10점)**: 정확한 발음과 자연스러운 억양 및 전달력
- **어휘 점수 (0-10점)**: 올바른 어휘 및 표현 사용
- **유창성 점수 (0-10점)**: 유창성 수준

## 🔧 설정

### OpenAI API 키 설정
```env
OPENAI_API_KEY=your_openai_api_key_here
```

### Queue 설정
```env
QUEUE_CONNECTION=database
```

### 파일 저장소 설정
```env
FILESYSTEM_DISK=s3
AWS_ACCESS_KEY_ID=your_aws_key
AWS_SECRET_ACCESS_KEY=your_aws_secret
AWS_DEFAULT_REGION=ap-northeast-2
AWS_BUCKET=your_bucket_name
```

## 📈 성능 최적화

- **청크 분할**: 대용량 파일을 5분 단위로 분할 처리
- **압축 최적화**: MP3 압축으로 파일 크기 최소화
- **Queue 처리**: 비동기 처리로 서버 부하 분산
- **에러 처리**: 실패한 작업 자동 재시도

## 🛠️ 문제 해결

### 일반적인 문제들

1. **FFmpeg 설치 필요**
   ```bash
   # Ubuntu/Debian
   sudo apt install ffmpeg
   
   # CentOS/RHEL
   sudo yum install ffmpeg
   
   # macOS
   brew install ffmpeg
   ```

2. **OpenAI API 키 설정**
   ```bash
   php artisan config:clear
   ```

3. **Queue Worker 재시작**
   ```bash
   php artisan queue:restart
   ```

## 📝 라이선스

이 프로젝트는 MIT 라이선스 하에 배포됩니다.

## 🤝 기여하기

1. Fork the Project
2. Create your Feature Branch (`git checkout -b feature/AmazingFeature`)
3. Commit your Changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the Branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📞 지원

문제가 발생하거나 질문이 있으시면 이슈를 생성해 주세요.
