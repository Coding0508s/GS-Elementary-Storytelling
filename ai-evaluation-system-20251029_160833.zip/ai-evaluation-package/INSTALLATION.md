# AI 일괄 체점 시스템 설치 가이드

## 📋 필수 요구사항

- PHP 8.1 이상
- Laravel 10.0 이상
- FFmpeg (오디오 추출용)
- MySQL/PostgreSQL/SQLite
- OpenAI API 키

## 🚀 설치 단계

### 1. 의존성 설치
```bash
composer install
```

### 2. 환경 설정
```bash
cp .env.example .env
# .env 파일에서 OpenAI API 키 설정
```

### 3. 데이터베이스 설정
```bash
php artisan migrate
```

### 4. 라우트 등록
`routes/web.php`에 다음 라인 추가:
```php
require_once __DIR__ . '/ai-evaluation.php';
```

### 5. Queue Worker 설정
```bash
php artisan queue:work --verbose --tries=3 --timeout=600
```

### 6. FFmpeg 설치
```bash
# Ubuntu/Debian
sudo apt update && sudo apt install ffmpeg

# CentOS/RHEL
sudo yum install ffmpeg

# macOS
brew install ffmpeg
```

## 🔧 사용법

1. 관리자 페이지에서 "영상 일괄 채점" 메뉴 접근
2. "일괄 AI 채점 시작" 버튼 클릭
3. 실시간으로 진행 상황 확인
4. 필요시 "일괄 AI 채점 취소" 버튼으로 중단

## 📊 기능

- OpenAI Whisper를 사용한 음성 인식
- GPT-4를 사용한 영어 발표 평가
- 대용량 파일 분할 처리
- 실시간 진행 상황 모니터링
- 실패한 평가 재시도 기능
- 관리자 권한 기반 접근 제어

## 🛠️ 문제 해결

### FFmpeg 오류
- FFmpeg가 설치되어 있는지 확인
- PATH에 FFmpeg가 포함되어 있는지 확인

### OpenAI API 오류
- API 키가 올바른지 확인
- API 사용량 한도 확인

### Queue Worker 오류
- 데이터베이스 연결 확인
- Queue 테이블 존재 여부 확인
