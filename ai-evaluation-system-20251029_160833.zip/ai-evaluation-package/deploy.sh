#!/bin/bash

# AI 일괄 체점 시스템 배포 스크립트

echo "🚀 AI 일괄 체점 시스템 배포 시작..."

# 1. 의존성 설치
echo "📦 Composer 의존성 설치 중..."
composer install --no-dev --optimize-autoloader

# 2. 환경 설정
echo "⚙️ 환경 설정 중..."
if [ ! -f .env ]; then
    cp .env.example .env
    echo "⚠️  .env 파일이 생성되었습니다. OpenAI API 키를 설정해주세요."
fi

# 3. 애플리케이션 키 생성
echo "🔑 애플리케이션 키 생성 중..."
php artisan key:generate

# 4. 캐시 클리어
echo "🧹 캐시 클리어 중..."
php artisan config:clear
php artisan cache:clear
php artisan view:clear
php artisan route:clear

# 5. 데이터베이스 마이그레이션
echo "🗄️ 데이터베이스 마이그레이션 실행 중..."
php artisan migrate --force

# 6. 스토리지 링크
echo "🔗 스토리지 링크 생성 중..."
php artisan storage:link

# 7. 권한 설정
echo "🔐 권한 설정 중..."
chmod -R 775 storage bootstrap/cache
chown -R www-data:www-data storage bootstrap/cache

# 8. Queue 테이블 생성
echo "📊 Queue 테이블 생성 중..."
php artisan queue:table
php artisan migrate

# 9. Supervisor 설정
echo "⚙️ Supervisor 설정 중..."
if [ -f supervisor-queue-worker.conf ]; then
    sudo cp supervisor-queue-worker.conf /etc/supervisor/conf.d/
    sudo supervisorctl reread
    sudo supervisorctl update
    sudo supervisorctl start laravel-queue-worker:*
fi

echo "✅ 배포 완료!"
echo "📝 다음 단계:"
echo "1. .env 파일에서 OpenAI API 키 설정"
echo "2. Queue Worker 시작: php artisan queue:work"
echo "3. 관리자 페이지 접속: /admin/batch-evaluation"
